import pandas as pd
from bs4 import BeautifulSoup
import nltk
import re
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer
import numpy as np



train = pd.read_csv("mergedSet.tsv", header = 0, delimiter = "\t", quoting = 3)



clean_train = train


def reviewToWords(review):
    #HTML removed
    review_text = BeautifulSoup(review).get_text()
    
    #Non-letters removed
    only_letters = re.sub("[^a-zA-Z]", " ", review_text) 
    
    #Convert to lower case and split
    words = only_letters.lower().split()
    
    #Convert stop words to a set because its faster
    stops = set(stopwords.words("english"))
    
    #Remove stop words
    req_words = [w for w in words if not w in stops]
    
    #Join words separated by space and return
    return(' '.join(req_words))
    
count = train["review"].size


clean_list = []

for i in xrange(count) :
    clean_train["review"][i] = reviewToWords(train["review"][i])
    clean_list.append(reviewToWords(train["review"][i]))
    
clean_train.to_csv("cleanReviews.tsv", delimiter = "\t", sep = '\t')    


#creating vocabulary
vectorizer = CountVectorizer(analyzer = "word", min_df = 2)
trainDataFeatures = vectorizer.fit_transform(clean_list)
trainDataFeatures = trainDataFeatures.toarray()

vocabulary = vectorizer.get_feature_names()

dist = np.sum(trainDataFeatures, axis = 0)

f = open('vocabulary.txt' , 'w')
for v in vocabulary:
    f.write(v + '\n')
    
f.close()
