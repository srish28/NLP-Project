import pandas as pd
from bs4 import BeautifulSoup
import nltk
import re
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer
import numpy as np
from collections import Counter
import pickle
import math
from sklearn import cross_validation



train = pd.read_csv("data.tsv", header = 0, delimiter = "\t", quoting = 3)



clean_train = train


def reviewToWords(review):
    #HTML removed
    review_text = BeautifulSoup(review).get_text()
    
    #Non-letters removed
    only_letters = re.sub("[^a-zA-Z]", " ", review_text) 
    
    #Convert to lower case and split
    words = only_letters.lower().split()
    
    #Convert stop words to a set because its faster
    #stops = set(stopwords.words("english"))
    stops=set(line.strip() for line in open('stopwords.txt'))
    
    #Remove stop words
    req_words = [w for w in words if not w in stops]
    
    #Join words separated by space and return
    return(' '.join(req_words))
    
count = train["review"].size


clean_list = []

for i in xrange(count) :
    clean_train["review"][i] = reviewToWords(train["review"][i])
    clean_list.append(reviewToWords(train["review"][i]))
    
clean_train.to_csv("cleanReviews.tsv", delimiter = "\t", sep = '\t')

print "Data Cleaned"
add = 0


#Predict Class of the given text
def make_class_prediction(text, tc, counts, class_prob, class_count):
    prediction = 1.0
    s = []
    s = s + text.split()
    text_count = len(s)
   
    for  i in xrange(text_count):
        if s[i] in tc:
            prediction *= (tc[s[i]] + 1.0) / (len(tc) + len(counts))
        else:
            prediction *= 1.0 / (len(tc) + len(counts))        

        
    return prediction


#10 Fold Cross Validation
#Splitting
X = clean_train["review"]
y = train["sentiment"]
skf = cross_validation.StratifiedKFold(y, n_folds = 10)

avgacc = 0.0
cv = 1

print "Cross Validating"

for train_index, test_index in skf:
    unidict = {}
    print "Cross Validating : ", cv
    cv = cv + 1
    for i in xrange(train_index.shape[0]):
        tokens = X[train_index[i]].split()
        for it in tokens:
            s = str(it)
            if s in unidict:
    		    c = unidict[s]
    	    else:
    	        c = 0
            unidict.update({s:c + 1})
                

    for v, c in list(unidict.items()):
        if c < 2:
            del unidict[v]

    vocab = unidict.keys()
    vocab.sort()
    
    print "Training model now. . . "
    #Training model
    positive_text = []
    negative_text = []
    
    
    updict = {}
    undict = {}


    #getting text together for a positive sentiment
    for i in xrange(len(train_index)):
        if y[train_index[i]] == '+':
            positive_text = positive_text + X[train_index[i]].split()
        else:
            negative_text = negative_text + X[train_index[i]].split()
    print "Positive & Negative text done!"

	#getting count for all positive sentiment words
    for it in positive_text:
        item = str(it)
        if item in updict:
    		c = updict[item]
    	else:
    	    c = 0
        updict.update({item:c + 1})
				
    print "Positive count done!"
	
	#getting count for all negative sentiment words
    for it in negative_text:
        item = str(it)
        if item in undict:
            c = undict[item]
        else:
    	    c = 0
        undict.update({item:c + 1})
	
    print "Negative count done!"
				
    positive_count = list(updict.items())
    negative_count = list(undict.items())
    
    print "Got the count and list."
    
    #Naive Bayes model prediction
    #count of +ve class
    countp = 0
    length = len(train_index)
    for i in xrange(length):
		if y[train_index[i]] == '+':
			countp = countp + 1

    print "Postive classes counted"

	#count of -ve class
    countn = 0
    for i in xrange(length):
		if y[train_index[i]] == '-':
			countn = countn + 1

    print "Negative classes counted"

	#class probabilities
    probp = countp/(length * 1.0)
    probn = countn/(length * 1.0)
    
    print "Probabilities claculated"

    pdict = {}
    ndict = {}
    tc = {}
	#dict with all the words and their +ve probabilites
    a = updict
    b = undict
    
    
    tc = dict(a.items() + b.items() + [(k, a[k] + b[k]) for k in set(b) & set(a)])
    print "Creating Separate Dictionary"
	
    for v in vocab:
		pdict.update({v:make_class_prediction(v, tc, updict, probp, countp)})

   
	#dict with all the words and their -ve probabilites
    for v in vocab:
    	ndict.update({v:make_class_prediction(v,tc, undict, probn, countn)})

    print "Testing now. . ."
    #Testing
    p = pdict
    n = ndict
    acc = 0.0
    truep=0.0
    truen=0.0
    falsep=0.0
    falsen=0.0
     
    for i in xrange(len(test_index)):
        posprob = 0.0
        negprob = 0.0

        s = []
        s = s + X[test_index[i]].split()
        text_count = len(s)
        for j in xrange(text_count):
            if s[j] in vocab:
                if s[j] in p:
                    posprob +=  math.log(p[s[j]])

                if s[j] in n:
                    negprob +=  math.log(n[s[j]])
            else:
                w = str(s[j])
                pp = make_class_prediction(w, tc, updict, probp, countp)
                np = make_class_prediction(w, tc, undict, probn, countn)

                posprob += math.log(pp)
                negprob += math.log(np)

		if probp > probn:
			if y[test_index[i]] == '+':
				truep = truep + 1.0
			else:
				falsep = falsep + 1.0
		else:
			if y[test_index[i]] == '-':
				truen = truen + 1.0
			else:
				falsen = falsen + 1.0
		
    acc = (truep + truen)/(truep + truen + falsep + falsen)
    print acc
    
    avgacc = avgacc + acc
    

avgacc = avgacc / 10
print avgacc

